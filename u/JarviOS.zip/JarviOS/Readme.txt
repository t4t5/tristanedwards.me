JarviOS
Made by Tristan Edwards (@t4t5) - 2014

You are hereby free to use this theme for whatever you want.

—————————————————————————————————————————

To install:

1. Download Winterboard, OpenSSH, ClearFolders and TransparentDock from Cydia.
2. Use SSH to put the JarviOS.theme folder in /Library/Themes
3. Launch Winterboard and choose JarviOS